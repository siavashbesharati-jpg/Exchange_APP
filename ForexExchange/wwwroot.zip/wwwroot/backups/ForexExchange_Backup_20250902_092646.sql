-- ForexExchange Database Backup
-- Created: 9/2/2025 9:26:46 AM

INSERT INTO Customers (Id, FullName, PhoneNumber, NationalId, Email, CreatedAt) VALUES ('1', 'سیستم ', '0000000000', '0000000000', 'system@exchange.local', '9/1/2025 9:35:53 PM');
INSERT INTO Customers (Id, FullName, PhoneNumber, NationalId, Email, CreatedAt) VALUES ('2', 'ALI BESHARATI NIA', '0096871746098', '', '', '9/2/2025 9:25:15 AM');
